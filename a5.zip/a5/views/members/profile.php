
<?php include('views/elements/header.php');?>

<div class="container">
    <div class="page-header">

        <h1><?php echo $title;?></h1>
    </div>

    <h3><?php echo $first_name . " " .$last_name ?></h3>
    <h4><?php echo $email?></h4>

</div>
