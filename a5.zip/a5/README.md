Assignment 5 - Final Project Part 1
==========

This exercise added on to Assignment 4


```
 /root 
    ﹂/application
         ﹂/controllers
            ﹂controller.class.php
            ﹂managepostscontroller.class.php
            ﹂blogcontroller.class.php
            ﹂logincontroller.class.php
            ﹂memberscontroller.class.php
            ﹂registercontroller.class.php
         ﹂/models
            ﹂category.php
            ﹂model.php
            ﹂post.php
            ﹂user.php
         ﹂load.php
         ﹂router.php
    ﹂/views
         ﹂/elements
            ﹂footer.php
            ﹂header.php
         ﹂/404  
            ﹂index.php
         ﹂/blog
            ﹂index.php
            ﹂post.php         
         ﹂/home
            ﹂index.php
         ﹂/login
            ﹂index.php
         ﹂/manageposts
            ﹂add.php
            ﹂edit.php
            ﹂index.php
         ﹂/members
            ﹂index.php
            ﹂profile.php
         ﹂/register
            ﹂index.php
    ﹂index.php
    ﹂README.md

```
This assignment has the following:
- New Theme (United)
- New Commenting System for registered users
- Admins have privilege to delete all comments
- Admins can edit/delete posts and manage post categories