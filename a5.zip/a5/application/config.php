<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:22341/CIT313/SP2018/final1/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'turnerec');
define('DB_PASS', 'e5bJ1vQ1');
define('DB_NAME', 'turnerec_db');